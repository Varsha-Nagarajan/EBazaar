
package thebazaar;

import com.opensymphony.xwork2.ActionSupport;
import com.sun.corba.se.spi.presentation.rmi.StubAdapter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

public class AuthCheck extends ActionSupport implements ServletRequestAware,ServletResponseAware{

    private String user;
    private String pass;
    HttpServletRequest hsr;
    HttpServletResponse hsrp;

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    public String execute() throws IOException {
        String result = null;
        if(hsr.getParameter("submit").equals("Login"))
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "sayan");
                PreparedStatement ps = con.prepareStatement("select utype from login where uname=? and upass=?");
                ps.setString(1, getUser());
                ps.setString(2, getPass());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) 
                {
                    HttpSession hs=hsr.getSession(true);
                    hs.setAttribute("username",getUser());
                    String type = rs.getString(1);

                    if (type.equalsIgnoreCase("Admin")) 
                    {
                        result = "Admin";
                    } 
                    else 
                    {
                        result = "User";
                    }

                }
                else
                {
                     result="Error";
                     hsr.setAttribute("msg", "No Records Found! Please Register!");
                }
                return result;

            } 
            catch (Exception ex)
            {
                System.out.println("Exception >> " + ex);
            }
        }
        else
        {
            hsrp.sendRedirect("NewUser.jsp");
            
        }
        return result;
    }

    public void setServletRequest(HttpServletRequest hsr) {
       
        this.hsr=hsr;
        
    }
    
    public void validate() {
    
       if(getUser()== null || getUser().length() < 1)
       {
           addFieldError("user", "Username is Required.");
       }
       
       if(getPass()== null || getPass().length() < 1)
       {
           addFieldError("pass", "Password is Required.");
       }
    }

    public void setServletResponse(HttpServletResponse hsr) {
       hsrp=hsr;
    }

}
