/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package thebazaar;

import com.opensymphony.xwork2.ActionSupport;
import java.sql.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

/**
 *
 * @author Del
 */
public class CheckReg extends ActionSupport implements ServletRequestAware,ServletResponseAware{ 
    
    private String user;
    private String pass;
    private String name;
    private String addr;
    private String phno;
    HttpServletRequest hsr;
    HttpServletResponse hsrp;
    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }

    /**
     * @return the conp
     */
    

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the addr
     */
    public String getAddr() {
        return addr;
    }

    /**
     * @param addr the addr to set
     */
    public void setAddr(String addr) {
        this.addr = addr;
    }

    /**
     * @return the phno
     */
    public String getPhno() {
        return phno;
    }

    /**
     * @param phno the phno to set
     */
    public void setPhno(String phno) {
        this.phno = phno;
    }
    public void validate() {
    
       if(getUser()== null || getUser().length() < 1)
       {
           addFieldError("user", "Username is Required.");
       }
       
       if(getPass()== null || getPass().length() < 1)
       {
           addFieldError("pass", "Password is Required.");
       }
       if(getAddr()== null || getAddr().length() < 1)
       {
           addFieldError("addr", "Address is Required.");
       }
       
       if(getName()== null || getName().length() < 1)
       {
           addFieldError("name", "Name is Required.");
       }
       if(getPhno()== null || getPhno().length() < 1)
       {
           addFieldError("phno", "Contact Number is Required.");
       }
    }
    public void setServletRequest(HttpServletRequest hsr) {
       
        this.hsr=hsr;
}
    public void setServletResponse(HttpServletResponse hsr) {
       hsrp=hsr;
    }
    public String execute()
    {
        String result="Error";
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "sayan");
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from registration where username='"+user+"'");
        if(!(rs.next()))
        {
            String str="insert into registration values('"+user+"','"+pass+"','"+name+"','"+addr+"','"+phno+"')";
            int a=st.executeUpdate(str);
            String u="user";
            String str2="insert into login values('"+user+"','"+pass+"','"+u+"')";
            int a1=st.executeUpdate(str2);
            result="success";
            hsr.setAttribute("msg", "Registration successful. Login to continue!");
        }
        else
                {
                     result="Error";
                     hsr.setAttribute("msg", "Username already taken. Try another one!");
                }
        
    }
        catch(Exception ex){
        System.out.println("Exception is "+ex);}
        return result;
}
    
}
