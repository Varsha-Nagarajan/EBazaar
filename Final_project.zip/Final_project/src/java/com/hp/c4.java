/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hp;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import java.sql.*;


public class c4 implements ServletRequestAware{
    
    private String table;
    private String id;
    private String name;
    private String desc;
    private Float price;
    private String imgname;
    private int sold;
    HttpServletRequest req;
    Session s=NewHibernateUtil.getSessionFactory().openSession();
    Transaction t=s.beginTransaction();  


      
    public  String  execute()
    {
        String result="Failed";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","sayan");
            PreparedStatement ps=con.prepareStatement("select * from "+getTable()+" where pid = '"+getId()+"'");
           
            ResultSet rs= ps.executeQuery();
            
            if(rs.next())
            {
                if(getName().equals(""))
                    setName(rs.getString("pname"));
                if(getDesc().equals(""))
                    setDesc(rs.getString("pdesc"));
                if(getPrice()==0.0f)
                    setPrice(rs.getFloat("pprice"));
                if(getSold()==0)
                    setSold(Integer.parseInt(String.valueOf(getPrice())));
                  //  setSold(rs.getInt("psold")); 
            }
             
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+e);
        }
                     
            Cameras c=(Cameras)s.get(Cameras.class,new String(getId()));
            Consoles c1=(Consoles)s.get(Consoles.class,new String(getId()));
            Earphones e=(Earphones)s.get(Earphones.class,new String(getId()));
            Games g=(Games)s.get(Games.class,new String(getId()));
            Laptops l=(Laptops)s.get(Laptops.class,new String(getId()));
            Phones p=(Phones)s.get(Phones.class,new String(getId()));
            Tablets t1=(Tablets)s.get(Tablets.class,new String(getId()));
            
            if("cameras".equals(getTable()))
            {
            c.setPname(getName());
            c.setPdesc(getDesc());
           // c.setPimgname(getImgname());
            c.setPprice(getPrice());
            c.setPsold(getSold());
            s.update(c);
            result=trans();
            }
            else if("consoles".equals(getTable()))
            {
            c1.setPname(getName());
            c1.setPdesc(getDesc());
            //c1.setPimgname(getImgname());
            c1.setPprice(getPrice());
            c1.setPsold(getSold());
            s.update(c1);
            result=trans();
            }
            else if("earphones".equals(getTable()))
            {
            e.setPname(getName());
            e.setPdesc(getDesc());
            //e.setPimgname(getImgname());
            e.setPprice(getPrice());
            e.setPsold(getSold());
            s.update(e);
           result=trans();
            }
            else if("games".equals(getTable()))
            {
            g.setPname(getName());
            g.setPdesc(getDesc());
           // g.setPimgname(getImgname());
            g.setPprice(getPrice());
            g.setPsold(getSold());
            s.update(g);
            result=trans();
            }
            if("laptops".equals(getTable()))
            {
            l.setPname(getName());
            l.setPdesc(getDesc());
            //l.setPimgname(getImgname());
            l.setPprice(getPrice());
            l.setPsold(getSold());
            s.update(l);
           result=trans();
            }
            else if("phones".equals(getTable()))
            {
            p.setPname(getName());
            p.setPdesc(getDesc());
            //p.setPimgname(getImgname());
            p.setPprice(getPrice());
            p.setPsold(getSold());
            s.update(p);
           result=trans();
            }
            else if("tablets".equals(getTable()))
            {
            t1.setPname(getName());
            t1.setPdesc(getDesc());
           // t1.setPimgname(getImgname());
            t1.setPprice(getPrice());
            t1.setPsold(getSold());
            s.update(t1);
            result=trans();
            }
        return result;
    }
    
    private String trans()
       {
                  t.commit();
                 if(t.wasCommitted())
                 {
                     req.setAttribute("msg", "Success!");
                     return "Success";
                     
                 }
                 else{
                     req.setAttribute("msg", "Failed!");
                     return "Failed";
                     
                 }
       }
        
    public String getTable() {
        return table;
    }

    /**
     * @param table the table to set
     */
    public void setTable(String table) {
        this.table = table;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the price
     */
    public Float getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(Float price) {
        this.price = price;
    }

    /**
     * @return the imgname
     */
    public String getImgname() {
        return imgname;
    }

    /**
     * @param imgname the imgname to set
     */
    public void setImgname(String imgname) {
        this.imgname = imgname;
    }

    /**
     * @return the sold
     */
    public int getSold() {
        return sold;
    }

    /**
     * @param sold the sold to set
     */
    public void setSold(int sold) {
        this.sold = sold;
    }

    public void setServletRequest(HttpServletRequest hsr) {
       req=hsr;
    }
    
}
