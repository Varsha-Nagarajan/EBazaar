/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hp;

import com.opensymphony.xwork2.ActionSupport;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 *
 * @author User
 */
public class c3 extends ActionSupport implements ServletRequestAware{
    private String id;
    private String name;
    private String desc;
    private Float price;
    private String imgname;
    private String table;
    private File userImage;
    HttpServletRequest req;
    private String userImageContentType;
    private String userImageFileName;
    Session s=NewHibernateUtil.getSessionFactory().openSession();
        
        Transaction t=s.beginTransaction();
    
    public void setServletRequest(HttpServletRequest hsr) {
        req=hsr; 
    }

    
    public String execute()
    {
        String result="Failed";
       // Session s=NewHibernateUtil.getSessionFactory().openSession();
        
       // Transaction t=s.beginTransaction();
        
        String path=req.getSession().getServletContext().getRealPath("/")+"/images";
             File fileToCreate=new File(path,userImageFileName);
          try {
             FileUtils.copyFile(userImage, fileToCreate);
         } catch (IOException ex) {
            System.out.println(ex);
            }
          setUserImageFileName("images/"+userImageFileName);
        
        Cameras c=new Cameras(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Consoles c1=new Consoles(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Earphones e=new Earphones(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Games g=new Games(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Laptops l=new Laptops(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Phones p=new Phones(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        Tablets t1=new Tablets(getId(),getName(),getDesc(),getUserImageFileName(),getPrice(),0);
        
         
        if("cameras".equals(getTable()))
        {
          
            s.save(c);
            result=trans();
        }
       else if("consoles".equals(getTable()))
        {
        s.save(c1);
        result=trans();
        }
       else if("earphones".equals(getTable()))
        {
        s.save(e);
        result=trans();
        }
        if("games".equals(getTable()))
        {
        s.save(g);
        result=trans();
        }
        if("laptops".equals(getTable()))
        {
        s.save(l);
        result=trans();
        }
        if("phones".equals(getTable()))
        {
        s.save(p);
        result=trans();
        }
        if("tablets".equals(getTable()))
        {
        s.save(t1);
        result=trans();
        }
        return result;
    }

       private String trans()
       {
                  t.commit();
                 if(t.wasCommitted())
                 {
                     req.setAttribute("msg", "Success!");
                     return "Success";
                     
                 }
                 else{
                     req.setAttribute("msg", "Failed!");
                     return "Failed";
                     
                 }
       }
       
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the price
     */
    public Float getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(Float price) {
        this.price = price;
    }

    /**
     * @return the imgname
     */
    public String getImgname() {
        return imgname;
    }

    /**
     * @param imgname the imgname to set
     */
    public void setImgname(String imgname) {
        this.imgname = imgname;
    }

    /**
     * @return the table
     */
    public String getTable() {
        return table;
    }

    /**
     * @param table the table to set
     */
    public void setTable(String table) {
        this.table = table;
    }

    /**
     * @return the userImage
     */
    public File getUserImage() {
        return userImage;
    }

    /**
     * @param userImage the userImage to set
     */
    public void setUserImage(File userImage) {
        this.userImage = userImage;
    }

    /**
     * @return the userImageContentType
     */
    public String getUserImageContentType() {
        return userImageContentType;
    }

    /**
     * @param userImageContentType the userImageContentType to set
     */
    public void setUserImageContentType(String userImageContentType) {
        this.userImageContentType = userImageContentType;
    }

    /**
     * @return the userImageFileName
     */
    public String getUserImageFileName() {
        return userImageFileName;
    }

    /**
     * @param userImageFileName the userImageFileName to set
     */
    public void setUserImageFileName(String userImageFileName) {
        this.userImageFileName = userImageFileName;
    }
    
}
