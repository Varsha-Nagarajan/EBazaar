/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hp;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 *
 * @author User
 */
public class c5 implements ServletRequestAware {
    
    
    HttpServletRequest hsr;
    private String table;
    private String id;
    Session s=NewHibernateUtil.getSessionFactory().openSession();
    Transaction t=s.beginTransaction();
    
    public String execute()
    {
        String result=null;
        
        Cameras c=(Cameras)s.get(Cameras.class,new String(getId()));
        Consoles c1=(Consoles)s.get(Consoles.class,new String(getId()));
        Earphones e=(Earphones)s.get(Earphones.class,new String(getId()));
        Games g=(Games)s.get(Games.class,new String(getId()));
        Laptops l=(Laptops)s.get(Laptops.class,new String(getId()));
        Phones p=(Phones)s.get(Phones.class,new String(getId()));
        Tablets t1=(Tablets)s.get(Tablets.class,new String(getId()));
        if("cameras".equals(getTable()))
        {
            s.delete(c);
            result=trans();
        }
        
        else if("consoles".equals(getTable()))
        {
            s.delete(c1);
            
            result=trans();
        }
        else if("earphones".equals(getTable()))
        {
            s.delete(e);
           
            result=trans();
        }
        else if("games".equals(getTable()))
        {
            s.delete(g);
           result=trans();
        }
        else if("laptops".equals(getTable()))
        {
            s.delete(l);
           result=trans();
        }
        else if("phones".equals(getTable()))
        {
            s.delete(p);
           result=trans();
        }
        else if("tablets".equals(getTable()))
        {
            s.delete(t1);
            result=trans();
        }
        return result;
    }
     private String trans()
       {
                  t.commit();
                 if(t.wasCommitted())
                 {
                     hsr.setAttribute("msg", "Success!");
                     return "Success";
                     
                 }
                 else{
                     hsr.setAttribute("msg", "Failed!");
                     return "Failed";
                     
                 }
       }
       

    /**
     * @return the table
     */
    public String getTable() {
        return table;
    }

    /**
     * @param table the table to set
     */
    public void setTable(String table) {
        this.table = table;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    public void setServletRequest(HttpServletRequest hsr) {
        this.hsr=hsr;
    }
    
    
    
    
}
