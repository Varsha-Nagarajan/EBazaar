/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author User
 */
public class c1 {
    private String user;
    private String pass;

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the pass
     */
    public String getPass() {
        return pass;
    }

    /**
     * @param pass the pass to set
     */
    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public String execute()
    {
        String result=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root","sayan");
            PreparedStatement ps=con.prepareStatement("select utype from login where uname=? and upass=?");
            ps.setString(1,getUser());
            ps.setString(2,getPass());
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                String type=rs.getString(1);
                if(type.equalsIgnoreCase("Admin"))
                {
                     result="Admin";
                }
            }
            else
                result="Error";
            
        }
        catch(Exception e)
        {
            
        }
        
        return result;
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

